﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Latest_Staff_Portal.Models
{
    public class UserViewModel
    {
        public string UserName { get; set; }
        public string UserID { get; set; }
        public string RoleName { get; set; }
        public bool Full_Access { get; set; }
        public string Email { get; set; }
    }
}